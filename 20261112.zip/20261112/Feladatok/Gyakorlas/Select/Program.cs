﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Select
{
    internal class Program
    {
         struct tanulo
    {
        public string nev;
        public int szubeletesiEv;
        public bool fiu;
        public int magassag;
        public int testsuly;

    }
        static void Main(string[] args)
        {
            List<tanulo> tanulok = new List<tanulo>()
        {
       new tanulo {nev = "Nagy Geza", szubeletesiEv = 2000, fiu = true, magassag = 180, testsuly = 82},
new tanulo {nev = "Narancsos Piroska", szubeletesiEv = 2001, fiu = false, magassag = 160, testsuly = 52},
new tanulo {nev = "Alajos Lajos", szubeletesiEv = 2002, fiu = true, magassag = 172, testsuly = 89},
new tanulo {nev = "Fazekas Ferenc", szubeletesiEv = 1999, fiu = true, magassag = 168, testsuly = 66 },
new tanulo {nev = "Nagy Katalin", szubeletesiEv = 2000, fiu = false, magassag = 177, testsuly = 62},
new tanulo {nev = "Varga Peter", szubeletesiEv = 1998, fiu = true, magassag = 178, testsuly = 77},
new tanulo {nev = "Szucs Geza", szubeletesiEv = 2000, fiu = true, magassag = 179, testsuly = 80},
new tanulo {nev = "Peter Laszlo", szubeletesiEv = 1999, fiu = true, magassag = 180, testsuly = 82}
        };

 var ciganyPecsenye = 


        }
    }
}
