﻿


using System.Net.Http.Headers;
using System.Reflection.Metadata;
using System.Security.Cryptography.X509Certificates;

internal class program
{
    // structura amiben tanulo neven val elmentve
    struct tanulo
    {
        public string nev;
        public int szubeletesiEv;
        public bool fiu;
        public int magassag;
        public int testsuly;

    }


    static void Main(string[] args)
    {
        // lista betoltott adatokal
        List<tanulo> tanulok = new List<tanulo>()
        {
    new tanulo {nev ="Géza",szubeletesiEv = 2000,fiu = true, magassag = 180,testsuly = 82 },
    new tanulo {nev ="Pirosak",szubeletesiEv = 2001,fiu = false, magassag = 160,testsuly = 52 },
    new tanulo {nev ="Lajos",szubeletesiEv = 2002,fiu = true, magassag = 172,testsuly = 89 },
    new tanulo {nev ="Ferenc",szubeletesiEv = 1999,fiu = true, magassag = 168,testsuly = 66 },
        };

        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Tanulok Nevsora: LINQ-ban\n");
        Console.ResetColor();

        //LINQ megoldas

        var nevsor = from egyTanulo in tanulok 
                     select egyTanulo.nev;
        foreach(var item in nevsor)
        {
            Console.WriteLine(item);
        }

        Console.WriteLine();

        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Tanulok Nevsora: Lamdbda-ban\n");
        Console.ResetColor();

        //Lambda megooldas

        var Nevsor = tanulok.Select(x => x.nev);
        foreach (var item in Nevsor)
        {
            Console.WriteLine($"{item}");
        }

        Console.WriteLine();

        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Tanulok Névsora és Életkora: LINQ-ban\n");
        Console.ResetColor();

        //LINQ megoldas

        var Eletkor = from kettoT in tanulok
                      select new
                      {
                          nev = kettoT.nev,
                          eletkor = DateTime.Now.Year - kettoT.szubeletesiEv
                      };
        foreach(var item in Eletkor)
        {
            Console.WriteLine($"Nev: {item.nev,-8} - Eletkor: {item.eletkor,2}");
        }


        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Tanulok Névsora és Életkora: LAMBDA-ban\n");
        Console.ResetColor();

        //LAMBDA megoldas
        var NevsorEletkor = tanulok.Select(x => new
        {
            nev = x.nev,
            eletkor = DateTime.Now.Year - x.szubeletesiEv
        });
        foreach(var item in NevsorEletkor)
        {
            Console.WriteLine($"Név: {item.nev,-8} életkor: {item.eletkor,2} éves");
        }

        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Tanulok neve és Sulya: SQL-ban\n");
        Console.ResetColor();

        //SQL megoldas
        var TanTti = from TanT in tanulok
                     select new
                     {
                         nev = TanT.nev,
                         TanTTI = (double)(TanT.testsuly / ((TanT.magassag / 100.0) * (TanT.magassag / 100.0)))
    };
        foreach(var item in TanTti)
        {
            Console.WriteLine($"Név: {item.nev,-8} - TTI:{item.TanTTI:F2}");
        }
        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Tanulok neve és Sulya: LAMBDA-ban\n");
        Console.ResetColor();

        var lambadik = tanulok.Select(x => new
        {
            nev = x.nev,
            TanTTI = (double)(x.testsuly / ((x.magassag / 100.0) * (x.magassag / 100.0)))
        });

        foreach (var item in lambadik)
        {
            Console.WriteLine($"Név: {item.nev,-8} - TTI:{item.TanTTI:F2}");

        }

        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Tanulok neve és Sulya: LAMBDA-ban\n");
        Console.ResetColor();

        var TanulokMagass = from TanMag in tanulok
                            select new
                            {
                                nev = TanMag.nev,
                                TanMag = (double)(TanMag.magassag / 30.48),
                                TestSuly = (double)(TanMag.testsuly * 2.204621)
                            };
        foreach (var item in TanulokMagass)
        {
            Console.WriteLine($"Név: {item.nev,-8} - lab:{item.TanMag:F2} testuly: {item.TestSuly:F2}");

        }
















    }
}


