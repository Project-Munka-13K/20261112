﻿


internal class program
{
    // structura amiben tanulo neven val elmentve
    struct tanulo
    {
        public string nev;
        public int szubeletesiEv;
        public bool fiu;
        public int magassag;
        public int testsuly;

    }


    static void Main(string[] args)
    {
        // lista betoltott adatokal
        List<tanulo> tanulok = new List<tanulo>()
        {
            new tanulo {nev ="Géza",szubeletesiEv = 2000,fiu = true, magassag = 180,testsuly = 82 },
    new tanulo {nev ="Pirosak",szubeletesiEv = 2001,fiu = false, magassag = 180,testsuly = 82 },
    new tanulo {nev ="Lajos",szubeletesiEv = 2002,fiu = true, magassag = 180,testsuly = 82 },
    new tanulo {nev ="Ferenc",szubeletesiEv = 1999,fiu = true, magassag = 180,testsuly = 82 },
        };


        Console.WriteLine("\n Tanulok Nevsora: LINQ-ban");
        //LINQ megoldas
        var nevsor = from egyTanulo in tanulok 
                     select egyTanulo.nev;
        foreach(var item in nevsor)
        {
            Console.WriteLine(item);
        }


        Console.WriteLine("\n Tanulok Nevsora: Lamdbda-ban");
        //Lambda megooldas
        var Nevsor = tanulok.Select(x => x.nev);
        foreach (var item in Nevsor)
        {
            Console.WriteLine($"{item}");
        }

        var Eletkor = from kettoT in tanulok
                      select new
                      {
                          nev = kettoT.nev,
                          eletkor = DateTime.Now.Year - kettoT.szubeletesiEv
                      };
        
        

    


    }
}


